/*Kursheeka Milburn
March 22, 204
CS 210 Programming Languages*/


#include <iostream>
#include <iomanip>
#include <string>

using namespace std;

// Function to display the menu
void menuDisplay() {
    cout << "****************************\n";
    cout << "*     1 - Add One Hour     *\n";
    cout << "*     2 - Add One Minute   *\n";
    cout << "*     3 - Add One Second   *\n";
    cout << "*     4 - Exit Program     *\n";
    cout << "****************************\n";
}

// Function to display time in both 12-hour and 24-hour formats
void displayTime(int hrs, int mins, int secs) {
    string twentyfour = to_string(hrs) + ":" + to_string(mins % 60) + ":" + to_string(secs % 60);
    string twelve = to_string(hrs % 12) + ":" + to_string(mins % 60) + ":" + to_string(secs % 60) + (hrs < 12 ? " AM" : " PM");

    cout << "******************      ******************" << endl;
    cout << "*  12-Hour Clock *      *  24-Hour Clock *" << endl;
    cout << "*  " << setw(13) << twelve << " *      *  " << setw(13) << twentyfour << " *" << endl;
    cout << "******************      ******************" << endl;
}

int main() {
    int hrs = 13;
    int mins = 33;
    int secs = 12;

    while (true) {
        displayTime(hrs, mins, secs);
        menuDisplay();
        int input;
        cin >> input;

        // Exit program if input is 4
        if (input == 4) {
            cout << "Exiting program." << endl;
            break;
        }

        // Increment hours for input 1
        if (input == 1) {
            hrs = (hrs + 1) % 24;
        }

        // Increment minutes for input 2
        if (input == 2) {
            mins = (mins + 1) % 60;
            if (mins == 0) {
                hrs = (hrs + 1) % 24;
            }
        }

        // Increment seconds for input 3
        if (input == 3) {
            secs = (secs + 1) % 60;
            if (secs == 0) {
                mins = (mins + 1) % 60;
                if (mins == 0) {
                    hrs = (hrs + 1) % 24;
                }
            }
        }
    }

    return 0;
}